let database = [
	"meme"
]

export default database